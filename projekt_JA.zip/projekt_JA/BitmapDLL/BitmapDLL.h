#pragma once

#define DLLIMPORT __declspec(dllimport)
#define DLLEXPORT __declspec(dllexport)

int DLLEXPORT Function1c();
int DLLEXPORT Function2c();