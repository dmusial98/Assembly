#include "stdafx.h"
#include "CppDLL.h"


int FunctionCpp() {

	return 12;
}

