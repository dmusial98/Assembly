#include "pch.h"
#include <iostream>
#include "BitmapDLL.h"
#include "CppDLL.h"
#include <windows.h>

int main()
{
	Function1c();
	Function2c();
	FunctionCpp();

	return 0;
}

